<?php
defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Main page</title>
</head>

	<h1>HELLO!</h1>
	<div id="like_button_container"></div>

</body>
	<script src="https://unpkg.com/react@16/umd/react.development.js" crossorigin></script>
  	<script src="https://unpkg.com/react-dom@16/umd/react-dom.development.js" crossorigin></script>
  	<script type="text/babel" src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>
  	<script src="/assets/js/like_button.js"></script>
</html>